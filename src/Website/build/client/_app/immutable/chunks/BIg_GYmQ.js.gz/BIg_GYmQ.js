import{e}from"./oSUuz_k1.js";e();
