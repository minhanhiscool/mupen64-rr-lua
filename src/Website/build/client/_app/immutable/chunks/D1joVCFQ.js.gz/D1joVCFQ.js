const u=""+new URL("../assets/ugui.CzYIiB25.png",import.meta.url).href;export{u};
