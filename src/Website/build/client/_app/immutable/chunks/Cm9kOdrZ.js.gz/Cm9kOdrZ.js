const e=""+new URL("../assets/sm64luaredux.BaX7exeu.png",import.meta.url).href;export{e as s};
