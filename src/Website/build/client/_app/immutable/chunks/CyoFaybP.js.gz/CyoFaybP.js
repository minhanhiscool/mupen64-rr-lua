import{d as p,E as t}from"./oSUuz_k1.js";import{B as c}from"./ByzFFa6p.js";function E(r,s,...a){var e=new c(r);p(()=>{const n=s()??null;e.ensure(n,n&&(o=>n(o,...a)))},t)}export{E as s};
